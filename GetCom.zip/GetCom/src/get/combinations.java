package get;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class combinations  {
	 private Set<String> wordsSet;
    private StringBuilder output = new StringBuilder();
    private StringBuilder extract = new StringBuilder();
    ArrayList<String> al=new ArrayList<String>();
    private final String inputstring;
    public combinations( final String str ){
        inputstring = str;
        System.out.println("The input string  is  : " + inputstring);
    }
    
    
    public static void main (String args[])
    {
        combinations combobj= new combinations("Ravi");
        System.out.println("");
        System.out.println("All possible combinations are :  ");
        System.out.println("");
        combobj.combine();
    }
    
    public static boolean check_for_word(String word) {
        // System.out.println(word);
        try {
            BufferedReader in = new BufferedReader(new FileReader("C:\\Users\\travichandra\\Desktop\\EnglishWords.txt"));
            String str;
            
            while ((str = in.readLine()) != null) {
            	
                if (str.indexOf(word) != -1) {
                    return true;
                }
                
                
            }
            in.close();
        } catch (IOException e) {
        }

        return false;
    }
    public void get1234() throws IOException
    {
        Path path = Paths.get("C:\\Users\\travichandra\\Desktop\\EnglishWords.txt");
        byte[] readBytes = Files.readAllBytes(path);
        String wordListContents = new String(readBytes, "UTF-8");
        String[] words = wordListContents.split("\n");
        wordsSet = new HashSet<>();
        Collections.addAll(wordsSet, words);
    }

    public boolean contains(String word)
    {
        return wordsSet.contains(word);
        
    }
    public void combine() { 
    	combine( 0 );
    	System.out.println(al);
    	}
    private void combine(int start ){
         for( int i = start; i < inputstring.length(); ++i ){
            output.append( inputstring.charAt(i) );
          //  System.out.println( output );
            String singleString = output.toString();
            if(check_for_word(singleString)) {
            	al.add(singleString);
            	
            }
            if ( i < inputstring.length() )
            combine( i + 1);
            output.setLength( output.length() - 1 );
            
        }
         
    }


	
} 